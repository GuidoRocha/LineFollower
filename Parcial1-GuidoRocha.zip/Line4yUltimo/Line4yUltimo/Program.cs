﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Dominio;
using BLL;
using BLL.Factory;
using Services;
using BLL.DTO;

namespace Line4yUltimo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("===========================");
            Console.WriteLine("  Proyecto LineFollower ");
            Console.WriteLine("===========================\n");
            Console.WriteLine("Aclaracion: Al momento de ejecutar el proyecto el robot esta avanzando (SensorDerecho = True // SensorIzquierdo = True)");
            Console.WriteLine("para cambiar los estados de los sensores, estos no pueden ser iguales al estado anteriro");

            IRobotFactory factory = new RobotFactory();
            Robot robot = factory.CrearRobot();
            RobotLogic robotService = new RobotLogic(robot);

            bool continuar = true;

            while (continuar)
            {
                // MENU
                Console.WriteLine("\nMenu:");
                Console.WriteLine("1. Actualizar Sensores");
                Console.WriteLine("2. Consultar Registros");
                Console.WriteLine("3. Buscar registros por fecha");
                Console.WriteLine("4. Salir");

                Console.Write("Elija una opción: ");
                string opcion = Console.ReadLine();

                switch (opcion)
                {
                    case "1":
                        ActualizarSensoresTresVeces(robotService);
                        break;

                    case "2":
                        // Consultar registros guardados en memoria
                        ConsultarRegistros(robotService);
                        break;

                    case "3":
                        // Buscar registros por fecha
                        BuscarRegistrosPorFecha(robotService);
                        break;

                    case "4":
                        // Salir del programa
                        continuar = false;
                        break;

                    default:
                        Console.WriteLine("Opción inválida. Intente de nuevo.");
                        break;
                }
            }
        }

        //  Ejecutar 3 veces esperando 2 segundos entre cada una
        private static void ActualizarSensoresTresVeces(RobotLogic robotService)
        {
            Console.WriteLine("Actualizar Sensores (3 veces):");

            for (int i = 1; i <= 3; i++)
            {
                Console.WriteLine($"\nIngreso {i} de 3:");

                //Sensor izquierdo
                Console.WriteLine("Ingrese el valor del sensor izquierdo (True=Negro, False=Blanco):");
                bool sensorIzquierdo = ObtenerValorSensor();

                //Sensor derecho
                Console.WriteLine("Ingrese el valor del sensor derecho (True=Negro, False=Blanco):");
                bool sensorDerecho = ObtenerValorSensor();

                //Actualizar
                robotService.ActualizarSensores(sensorIzquierdo, sensorDerecho);

                //Esperar 2 segundos para el siguien
                if (i < 3) 
                {
                    Console.WriteLine("Esperando 2 segundos...");
                    Thread.Sleep(2000);
                }
            }

            //Volver al menuu
            Console.WriteLine("\nLos registros han sido ingresados exitosamente. Volviendo al menú...");
        }

        private static void ConsultarRegistros(RobotLogic robotService)
        {
            // Obtener los registros desde la BLL
            List<RegistroEstadoRobotDTO> registros = robotService.ObtenerRegistrosEnMemoria();

            if (registros.Count == 0)
            {
                Console.WriteLine("No hay registros disponibles.");
            }
            else
            {
                Console.WriteLine("\nRegistros en memoria:");
                Console.WriteLine("Fecha/Hora, Sensor Izquierdo, Sensor Derecho");

                foreach (var registro in registros)
                {
                    Console.WriteLine($"{registro.FechaHora}, {registro.SensorIzquierdo}, {registro.SensorDerecho}");
                }
            }
        }

        private static bool ObtenerValorSensor()
        {
            while (true)
            {
                string entrada = Console.ReadLine();
                if (entrada.ToLower() == "true" || entrada == "1")
                {
                    return true;
                }
                else if (entrada.ToLower() == "false" || entrada == "0")
                {
                    return false;
                }
                else
                {
                    Console.WriteLine("Entrada inválida. Ingrese 'True' o 'False' (o 1 para True, 0 para False):");
                }
            }
        }

        private static void BuscarRegistrosPorFecha(RobotLogic robotService)
        {
            Console.WriteLine("Ingrese la fecha desde (formato: dd-mm-yyyy):");
            DateTime fechaDesde = DateTime.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese la fecha hasta (formato: dd-mm-yyyy):");
            DateTime fechaHasta = DateTime.Parse(Console.ReadLine());

            List<RegistroEstadoRobotDTO> registros = robotService.BuscarRegistrosPorFecha(fechaDesde, fechaHasta);

            if (registros.Count == 0)
            {
                Console.WriteLine("No hay registros en el rango de fechas.");
            }
            else
            {
                Console.WriteLine("\nRegistros encontrados:");
                Console.WriteLine("Fecha/Hora, Sensor Izquierdo, Sensor Derecho");

                foreach (var registro in registros)
                {
                    Console.WriteLine($"{registro.FechaHora}, {registro.SensorIzquierdo}, {registro.SensorDerecho}");
                }
            }
        }
    }
}
    


