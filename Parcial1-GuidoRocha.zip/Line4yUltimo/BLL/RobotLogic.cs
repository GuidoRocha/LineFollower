﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BLL.Strategy;
using Dominio;
using Services;
using DAO;
using BLL.DTO;
using DAO.Interfaz;

namespace BLL
{
    public class RobotLogic
    {
        private Robot _robot;
        private IRobotEstrategia _estrategia;
        private List<IRobotObserver> _observadores = new List<IRobotObserver>();
        private RobotEstadoLogger _logger; 

        public RobotLogic(Robot robot)
        {
            _robot = robot;
            IPersistencia persistencia = PersistenciaFactory.CrearPersistencia();
            _logger = new RobotEstadoLogger(persistencia);

            AgregarObservador(_logger);
        }

        // Agregar observador
        public void AgregarObservador(IRobotObserver observador)
        {
            _observadores.Add(observador);
        }

        // Notificar
        private void NotificarObservadores(EstadoRobot nuevoEstado)
        {
            foreach (var observador in _observadores)
            {
                observador.OnEstadoCambiado(nuevoEstado, _robot);
            }
        }

        //STRATERGY
        public void SetEstrategia(IRobotEstrategia estrategia)
        {
            _estrategia = estrategia;
        }

        public void ActualizarSensores(bool sensorIzquierdo, bool sensorDerecho)
        {
            // Actualizamos los sensores del robot con los valores ingresados
            _robot.SensorIzquierdo.IsLineDetected = sensorIzquierdo;
            _robot.SensorDerecho.IsLineDetected = sensorDerecho;

            //evaluamos el estado del robot
            ActualizarEstado();
        }

        // Método que evalúa el estado del robot basado en los sensores
        private EstadoRobot EvaluarEstado()
        {
            if (_robot.SensorIzquierdo.IsLineDetected && _robot.SensorDerecho.IsLineDetected)
                return EstadoRobot.Avanzar;
            if (_robot.SensorIzquierdo.IsLineDetected && !_robot.SensorDerecho.IsLineDetected)
                return EstadoRobot.GirarIzquierda;
            if (!_robot.SensorIzquierdo.IsLineDetected && _robot.SensorDerecho.IsLineDetected)
                return EstadoRobot.GirarDerecha;
            return EstadoRobot.RetrocederYAdvertir;
        }

        private void ActualizarEstado()
        {
            EstadoRobot nuevoEstado = EvaluarEstado();
            if (nuevoEstado != _robot.EstadoActual)
            {
                _robot.EstadoActual = nuevoEstado;

                // DESAMBIGUADOR Seleccionamos la estrategia adecuada según el nuevo estado
                switch (nuevoEstado)
                {
                    case EstadoRobot.Avanzar:
                        SetEstrategia(new AvanzarEstrategia());
                        break;
                    case EstadoRobot.GirarIzquierda:
                        SetEstrategia(new GirarIzquierdaEstrategia());
                        break;
                    case EstadoRobot.GirarDerecha:
                        SetEstrategia(new GirarDerechaEstrategia());
                        break;
                    case EstadoRobot.RetrocederYAdvertir:
                        SetEstrategia(new RetrocederYAdvertirEstrategia());
                        break;
                }

                // Notificamos
                NotificarObservadores(nuevoEstado);

                // Ejecutamos la estrategia seleccionada
                EjecutarAccion();
            }
        }

        // ejecuta la acción del robot segun el estado
        private void EjecutarAccion()
        {
            _estrategia?.Ejecutar(_robot);
        }

        // Obtener los registros en memoria
        public List<RegistroEstadoRobotDTO> ObtenerRegistrosEnMemoria()
        {
            List<RegistroEstadoRobot> registrosDAO = _logger.ObtenerRegistrosEnMemoria();
            List<RegistroEstadoRobotDTO> registrosDTO = new List<RegistroEstadoRobotDTO>();

            // Convertimos los objetos de DAO a DTO
            foreach (var registro in registrosDAO)
            {
                registrosDTO.Add(new RegistroEstadoRobotDTO(
                    registro.FechaHora,
                    registro.SensorIzquierdo,
                    registro.SensorDerecho
                ));
            }

            return registrosDTO; // Devolvemos la lista de DTO
        }

        public List<RegistroEstadoRobotDTO> BuscarRegistrosPorFecha(DateTime fechaDesde, DateTime fechaHasta)
        {
            List<RegistroEstadoRobot> registrosDAO = _logger.BuscarRegistrosPorFecha(fechaDesde, fechaHasta);
            List<RegistroEstadoRobotDTO> registrosDTO = new List<RegistroEstadoRobotDTO>();

            // Convertimos los objetos de DAO a DTO
            foreach (var registro in registrosDAO)
            {
                registrosDTO.Add(new RegistroEstadoRobotDTO(
                    registro.FechaHora,
                    registro.SensorIzquierdo,
                    registro.SensorDerecho
                ));
            }
            return registrosDTO;
        }
    }
}
