﻿using Dominio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Factory
{
    public class RobotFactory : IRobotFactory
    {
        public Robot CrearRobot()
        {
            // Creamos el robot
            Robot robot = new Robot
            {
                SensorIzquierdo = new Sensor(),
                SensorDerecho = new Sensor(),
                MotorIzquierdo = new Motor(),
                MotorDerecho = new Motor(),
                ParlanteActivo = false,
                EstadoActual = EstadoRobot.Avanzar // Iniciar en "Avanzar"
            };
            return robot;
        }
    }
}
