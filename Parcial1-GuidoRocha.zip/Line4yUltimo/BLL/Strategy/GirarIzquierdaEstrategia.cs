﻿using Dominio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Strategy
{
    public class GirarIzquierdaEstrategia : IRobotEstrategia
    {
        public void Ejecutar(Robot robot)
        {
            robot.MotorIzquierdo.Power = 50;
            robot.MotorDerecho.Power = 50;
            robot.MotorIzquierdo.Direccion = false;
            robot.MotorDerecho.Direccion = true;
            robot.ParlanteActivo = false;
            Console.WriteLine("Robot girando a la izquierda");
        }
    }
}
