﻿using DAO.Interfaz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAO
{
    public static class PersistenciaFactory
    {
        public static IPersistencia CrearPersistencia()
        {
            // Clase para cambiar la estrategia de persistencia

            // persistencia binaria predeterminada.
            return new SerializadorBinario();

            // Ejemplos:

            // return new PersistenciaTextoPlano();

            // return new PersistenciaBaseDeDatos();
        }
    }
}
