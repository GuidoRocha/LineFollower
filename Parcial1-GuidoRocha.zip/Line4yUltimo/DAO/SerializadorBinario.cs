﻿using DAO.Interfaz;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace DAO
{
    public class SerializadorBinario : IPersistencia
    {
        private string _filePath;

        public SerializadorBinario()
        {
            string ruta = ConfigurationManager.AppSettings["RutaLogs"];

            // Verificar la ruta
            if (string.IsNullOrEmpty(ruta))
            {
                throw new Exception("La ruta de los logs no está configurada en App.config.");
            }

            // Crear si no existe
            if (!Directory.Exists(ruta))
            {
                Directory.CreateDirectory(ruta);
            }

            _filePath = Path.Combine(ruta, "mision.bin");
        }

        // Guardar un registro
        public void Guardar(RegistroEstadoRobot registro)
        {
            using (FileStream fs = new FileStream(_filePath, FileMode.Append, FileAccess.Write))
            {
                BinaryFormatter formatter = new BinaryFormatter();
                formatter.Serialize(fs, registro);
            }
        }

        // Cargar todos los registros
        public List<RegistroEstadoRobot> Cargar()
        {
            List<RegistroEstadoRobot> registros = new List<RegistroEstadoRobot>();

            if (File.Exists(_filePath))
            {
                using (FileStream fs = new FileStream(_filePath, FileMode.Open, FileAccess.Read))
                {
                    BinaryFormatter formatter = new BinaryFormatter();
                    while (fs.Position < fs.Length)
                    {
                        registros.Add((RegistroEstadoRobot)formatter.Deserialize(fs));
                    }
                }
            }

            return registros;
        }

        public List<RegistroEstadoRobot> BuscarRegistrosPorFecha(DateTime fechaDesde, DateTime fechaHasta)
        {
            List<RegistroEstadoRobot> todosRegistros = Cargar();  // Deserializamos todos los registros
            // Filtrar los registros que están entre las fechas especificadas
            var registrosFiltrados = todosRegistros
                .Where(r => r.FechaHora >= fechaDesde && r.FechaHora <= fechaHasta)
                .ToList();

            return registrosFiltrados;
        }
    }
}
