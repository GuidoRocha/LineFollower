﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAO.Interfaz
{
    public interface IPersistencia
    {
        // Guardar un registro
        void Guardar(RegistroEstadoRobot registro);

        // Cargar todos los registros
        List<RegistroEstadoRobot> Cargar();

        // Buscar registros por rango de fechas
        List<RegistroEstadoRobot> BuscarRegistrosPorFecha(DateTime fechaDesde, DateTime fechaHasta);
    }
}
