﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Motor
    {
        public int Power { get; set; }
        public bool Direccion { get; set; }  // True para ADELANTE      False para ATRAS
    }
}
