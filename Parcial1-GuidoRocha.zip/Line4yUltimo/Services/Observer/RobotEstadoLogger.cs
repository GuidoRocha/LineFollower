﻿using DAO;
using DAO.Interfaz;
using Dominio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services
{
    public class RobotEstadoLogger : IRobotObserver
    {
        private readonly IPersistencia _persistencia;
        private List<RegistroEstadoRobot> _registrosEnMemoria;

        public RobotEstadoLogger(IPersistencia persistencia)
        {
            _persistencia = persistencia;
            _registrosEnMemoria = new List<RegistroEstadoRobot>();
        }

        // Cuyando el Robot cambia de estado
        public void OnEstadoCambiado(EstadoRobot nuevoEstado, Robot robot)
        {
            var registro = new RegistroEstadoRobot(
                DateTime.Now,
                robot.SensorIzquierdo.IsLineDetected,
                robot.SensorDerecho.IsLineDetected
            );

            _registrosEnMemoria.Add(registro);
            _persistencia.Guardar(registro);
        }

        //obtener registros en memoria
        public List<RegistroEstadoRobot> ObtenerRegistrosEnMemoria()
        {
            return _registrosEnMemoria;
        }

        //No lo uso mas por la nueva metodologia

       /* // Método para cargar registros desde la persistencia
        public List<RegistroEstadoRobot> CargarRegistrosDesdePersistencia()
        {
            return _persistencia.Cargar();
        }
       */

        public List<RegistroEstadoRobot> BuscarRegistrosPorFecha(DateTime fechaDesde, DateTime fechaHasta)
        {
            List<RegistroEstadoRobot> todosRegistros = _persistencia.Cargar();  // Cargamos todos los registros desde la persistencia

            // Filtrar los registros que están entre las fechas especificadas
            var registrosFiltrados = todosRegistros.FindAll(r => r.FechaHora >= fechaDesde && r.FechaHora <= fechaHasta);

            return registrosFiltrados;
        }
    }
}
