﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dominio;

namespace BLL
{
    public class RobotLogic
    {
        private Robot _robot;

        // Constructor que recibe el robot del dominio
        public RobotLogic(Robot robot)
        {
            _robot = robot;
        }

        // Método para actualizar los sensores
        public void ActualizarSensores(bool sensorIzquierdo, bool sensorDerecho)
        {
            // Actualizamos los sensores del robot con los valores ingresados
            _robot.SensorIzquierdo.IsLineDetected = sensorIzquierdo;
            _robot.SensorDerecho.IsLineDetected = sensorDerecho;

            // Después de actualizar los sensores, evaluamos el estado del robot
            ActualizarEstado();
        }

        // Método que evalúa el estado del robot basado en los sensores
        private EstadoRobot EvaluarEstado()
        {
            if (_robot.SensorIzquierdo.IsLineDetected && _robot.SensorDerecho.IsLineDetected)
                return EstadoRobot.Avanzar;
            if (_robot.SensorIzquierdo.IsLineDetected && !_robot.SensorDerecho.IsLineDetected)
                return EstadoRobot.GirarIzquierda;
            if (!_robot.SensorIzquierdo.IsLineDetected && _robot.SensorDerecho.IsLineDetected)
                return EstadoRobot.GirarDerecha;
            return EstadoRobot.RetrocederYAdvertir;
        }

        // Método que actualiza el estado del robot y ejecuta la acción correspondiente
        private void ActualizarEstado()
        {
            EstadoRobot nuevoEstado = EvaluarEstado();
            if (nuevoEstado != _robot.EstadoActual)
            {
                _robot.EstadoActual = nuevoEstado;
                EjecutarAccion(nuevoEstado);
            }
        }

        // Método que ejecuta la acción del robot según el estado
        private void EjecutarAccion(EstadoRobot estado)
        {
            switch (estado)
            {
                case EstadoRobot.Avanzar:
                    _robot.MotorIzquierdo.Power = 100;
                    _robot.MotorDerecho.Power = 100;
                    _robot.MotorIzquierdo.Direccion = true;
                    _robot.MotorDerecho.Direccion = true;
                    _robot.ParlanteActivo = false;
                    Console.WriteLine("Robot avanzando");
                    break;

                case EstadoRobot.GirarIzquierda:
                    _robot.MotorIzquierdo.Power = 50;
                    _robot.MotorDerecho.Power = 50;
                    _robot.MotorIzquierdo.Direccion = false;
                    _robot.MotorDerecho.Direccion = true;
                    _robot.ParlanteActivo = false;
                    Console.WriteLine("Robot girando a la izquierda");
                    break;

                case EstadoRobot.GirarDerecha:
                    _robot.MotorIzquierdo.Power = 50;
                    _robot.MotorDerecho.Power = 50;
                    _robot.MotorIzquierdo.Direccion = true;
                    _robot.MotorDerecho.Direccion = false;
                    _robot.ParlanteActivo = false;
                    Console.WriteLine("Robot girando a la derecha");
                    break;

                case EstadoRobot.RetrocederYAdvertir:
                    _robot.MotorIzquierdo.Power = 50;
                    _robot.MotorDerecho.Power = 50;
                    _robot.MotorIzquierdo.Direccion = false;
                    _robot.MotorDerecho.Direccion = false;
                    _robot.ParlanteActivo = true;
                    Console.WriteLine("Robot retrocediendo y emitiendo sonido de advertencia");
                    break;
            }
        }
    }
}
