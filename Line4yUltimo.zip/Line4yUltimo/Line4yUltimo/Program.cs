﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Dominio;
using BLL;
using BLL.Factory;

namespace Line4yUltimo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Utilizamos la fábrica para crear el robot
            IRobotFactory factory = new RobotFactory();
            Robot robot = factory.CrearRobot();

            // Creamos el servicio del robot en la capa BLL
            RobotLogic RobotLogic = new RobotLogic(robot);

            // Iniciamos un ciclo para actualizar los sensores cada 2 segundos
            while (true)
            {
                // Pedimos el valor del sensor izquierdo al usuario
                Console.WriteLine("Ingrese el valor del sensor izquierdo (True=Negro, False=Blanco):");
                bool sensorIzquierdo = ObtenerValorSensor();

                // Pedimos el valor del sensor derecho al usuario
                Console.WriteLine("Ingrese el valor del sensor derecho (True=Negro, False=Blanco):");
                bool sensorDerecho = ObtenerValorSensor();

                // Actualizamos los sensores del robot usando el servicio de BLL
                RobotLogic.ActualizarSensores(sensorIzquierdo, sensorDerecho);

                // Pausamos la ejecución por 2 segundos antes de la próxima lectura
                Thread.Sleep(2000);  // 2000 milisegundos = 2 segundos
            }
        }

        // Función auxiliar para obtener el valor de un sensor desde la consola
        private static bool ObtenerValorSensor()
        {
            while (true)
            {
                string entrada = Console.ReadLine();
                if (entrada.ToLower() == "true" || entrada == "1")
                {
                    return true; // El sensor detecta la línea (negro)
                }
                else if (entrada.ToLower() == "false" || entrada == "0")
                {
                    return false; // El sensor no detecta la línea (blanco)
                }
                else
                {
                    Console.WriteLine("Entrada inválida. Ingrese 'True' o 'False' (o 1 para True, 0 para False):");
                }
            }
        }
    }  
}
