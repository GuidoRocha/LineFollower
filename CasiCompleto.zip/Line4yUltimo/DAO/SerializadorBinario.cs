﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace DAO
{
    public class SerializadorBinario
    {
        private string _filePath;
        private string _textFilePath;

        public SerializadorBinario()
        {
            // Leer la ruta desde App.config
            string rutaDirectorio = ConfigurationManager.AppSettings["RutaLogs"];

            // Verificar si la ruta es válida
            if (string.IsNullOrEmpty(rutaDirectorio))
            {
                throw new Exception("La ruta de los logs no está configurada en App.config.");
            }

            // Crear el directorio si no existe
            if (!Directory.Exists(rutaDirectorio))
            {
                Directory.CreateDirectory(rutaDirectorio);
            }

            // Construir la ruta completa del archivo
            _filePath = Path.Combine(rutaDirectorio, "mision.bin");
        }

        // Método para serializar un objeto (en este caso, RegistroEstadoRobot)
        public void Serializar(RegistroEstadoRobot registro)
        {
            using (FileStream fs = new FileStream(_filePath, FileMode.Append, FileAccess.Write))
            {
                BinaryFormatter formatter = new BinaryFormatter();
                formatter.Serialize(fs, registro);
            }
        }

        // Método para deserializar los registros
        public List<RegistroEstadoRobot> Deserializar()
        {
            List<RegistroEstadoRobot> registros = new List<RegistroEstadoRobot>();

            if (File.Exists(_filePath))
            {
                using (FileStream fs = new FileStream(_filePath, FileMode.Open, FileAccess.Read))
                {
                    BinaryFormatter formatter = new BinaryFormatter();
                    while (fs.Position < fs.Length)
                    {
                        registros.Add((RegistroEstadoRobot)formatter.Deserialize(fs));
                    }
                }
            }

            return registros;
        }
    }
}
