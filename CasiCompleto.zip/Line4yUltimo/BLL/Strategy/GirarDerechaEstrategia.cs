﻿using Dominio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Strategy
{
    public class GirarDerechaEstrategia : IRobotEstrategia
    {
        public void Ejecutar(Robot robot)
        {
            robot.MotorIzquierdo.Power = 50;
            robot.MotorDerecho.Power = 50;
            robot.MotorIzquierdo.Direccion = true;
            robot.MotorDerecho.Direccion = false;
            robot.ParlanteActivo = false;
            Console.WriteLine("Robot girando a la derecha");
        }
    }
}
