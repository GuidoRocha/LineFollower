﻿using Dominio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Strategy
{
    public class RetrocederYAdvertirEstrategia : IRobotEstrategia
    {
        public void Ejecutar(Robot robot)
        {
            robot.MotorIzquierdo.Power = 50;
            robot.MotorDerecho.Power = 50;
            robot.MotorIzquierdo.Direccion = false;
            robot.MotorDerecho.Direccion = false;
            robot.ParlanteActivo = true;
            Console.WriteLine("Robot retrocediendo y emitiendo sonido de advertencia");
        }
    }
}
