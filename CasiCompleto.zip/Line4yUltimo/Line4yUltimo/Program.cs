﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Dominio;
using BLL;
using BLL.Factory;
using Services;
using BLL.DTO;

namespace Line4yUltimo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Creamos el robot usando la fábrica
            IRobotFactory factory = new RobotFactory();
            Robot robot = factory.CrearRobot();

            // Creamos el servicio del robot (lógica de negocio) y pasamos el logger
            RobotEstadoLogger logger = new RobotEstadoLogger(); // Esto sigue en la capa Services
            RobotLogic robotService = new RobotLogic(robot, logger); // Pasamos el logger a la BLL

            bool continuar = true;

            while (continuar)
            {
                // Mostrar menú
                Console.WriteLine("\nMenú:");
                Console.WriteLine("1. Actualizar Sensores");
                Console.WriteLine("2. Consultar Registros");
                Console.WriteLine("3. Salir");

                Console.Write("Elija una opción: ");
                string opcion = Console.ReadLine();

                switch (opcion)
                {
                    case "1":
                        // Actualizamos los sensores
                        Console.WriteLine("Ingrese el valor del sensor izquierdo (True=Negro, False=Blanco):");
                        bool sensorIzquierdo = ObtenerValorSensor();

                        Console.WriteLine("Ingrese el valor del sensor derecho (True=Negro, False=Blanco):");
                        bool sensorDerecho = ObtenerValorSensor();

                        robotService.ActualizarSensores(sensorIzquierdo, sensorDerecho);
                        break;

                    case "2":
                        // Consultamos los registros guardados en memoria
                        ConsultarRegistros(robotService);
                        break;

                    case "3":
                        // Salir del programa
                        continuar = false;
                        break;

                    default:
                        Console.WriteLine("Opción inválida. Intente de nuevo.");
                        break;
                }
            }
        }

        // Método para consultar los registros guardados en memoria desde la BLL
        private static void ConsultarRegistros(RobotLogic robotService)
        {
            // Obtener los registros desde la BLL
            List<RegistroEstadoRobotDTO> registros = robotService.ObtenerRegistrosEnMemoria();

            if (registros.Count == 0)
            {
                Console.WriteLine("No hay registros disponibles.");
            }
            else
            {
                Console.WriteLine("\nRegistros en memoria:");
                Console.WriteLine("Fecha/Hora, Sensor Izquierdo, Sensor Derecho");

                foreach (var registro in registros)
                {
                    Console.WriteLine($"{registro.FechaHora}, {registro.SensorIzquierdo}, {registro.SensorDerecho}");
                }
            }
        }

        // Método para obtener el valor del sensor desde la consola
        private static bool ObtenerValorSensor()
        {
            while (true)
            {
                string entrada = Console.ReadLine();
                if (entrada.ToLower() == "true" || entrada == "1")
                {
                    return true;
                }
                else if (entrada.ToLower() == "false" || entrada == "0")
                {
                    return false;
                }
                else
                {
                    Console.WriteLine("Entrada inválida. Ingrese 'True' o 'False' (o 1 para True, 0 para False):");
                }
            }
        }
    }
}
    


