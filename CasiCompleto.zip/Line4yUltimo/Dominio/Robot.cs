﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Robot
    {
        public Sensor SensorIzquierdo { get; set; }
        public Sensor SensorDerecho { get; set; }
        public Motor MotorIzquierdo { get; set; }
        public Motor MotorDerecho { get; set; }
        public bool ParlanteActivo { get; set; }  // Indica si se está emitiendo sonido
        public EstadoRobot EstadoActual { get; set; }  // El estado actual del robot
    }
}
