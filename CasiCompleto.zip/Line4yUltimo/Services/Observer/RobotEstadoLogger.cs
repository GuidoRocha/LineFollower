﻿using DAO;
using Dominio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services
{
    public class RobotEstadoLogger : IRobotObserver
    {
        private SerializadorBinario _serializador;
        private List<RegistroEstadoRobot> _registrosEnMemoria;  // Lista para almacenar los registros en memoria

        public RobotEstadoLogger()
        {
            _serializador = new SerializadorBinario();  // Interactúa con la capa DAO
            _registrosEnMemoria = new List<RegistroEstadoRobot>();  // Inicializamos la lista
        }

        // Método que se llama cuando el robot cambia de estado
        public void OnEstadoCambiado(EstadoRobot nuevoEstado, Robot robot)
        {
            // Creamos un registro del cambio
            var registro = new RegistroEstadoRobot(
                DateTime.Now,
                robot.SensorIzquierdo.IsLineDetected,
                robot.SensorDerecho.IsLineDetected
            );

            // Guardamos el registro en la lista en memoria
            _registrosEnMemoria.Add(registro);

            // Llamamos al DAO para serializar el registro
            _serializador.Serializar(registro);
        }

        // Método para obtener los registros en memoria
        public List<RegistroEstadoRobot> ObtenerRegistrosEnMemoria()
        {
            return _registrosEnMemoria;
        }
    }
}
