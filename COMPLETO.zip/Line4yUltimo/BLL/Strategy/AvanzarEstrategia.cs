﻿using Dominio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Strategy
{
    public class AvanzarEstrategia : IRobotEstrategia
    {
        public void Ejecutar(Robot robot)
        {
            robot.MotorIzquierdo.Power = 100;
            robot.MotorDerecho.Power = 100;
            robot.MotorIzquierdo.Direccion = true;
            robot.MotorDerecho.Direccion = true;
            robot.ParlanteActivo = false;
            Console.WriteLine("Robot avanzando");
        }
    }
}
