﻿using Dominio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Factory
{
    public class RobotFactory : IRobotFactory
    {
        public Robot CrearRobot()
        {
            // Creamos el robot y sus componentes
            Robot robot = new Robot
            {
                SensorIzquierdo = new Sensor(),
                SensorDerecho = new Sensor(),
                MotorIzquierdo = new Motor(),
                MotorDerecho = new Motor(),
                ParlanteActivo = false,
                EstadoActual = EstadoRobot.Avanzar // Iniciar en "Avanzar"
            };

            // Se pueden configurar las propiedades de los sensores y motores aquí, si es necesario
            return robot;
        }
    }
}
