﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Motor
    {
        public int Power { get; set; }  // 0-100% de potencia
        public bool Direccion { get; set; }  // True si va hacia adelante, False hacia atrás
    }
}
