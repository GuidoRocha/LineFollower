﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAO
{
    [Serializable]
    public class RegistroEstadoRobot
    {
        public DateTime FechaHora { get; set; }
        public bool SensorIzquierdo { get; set; }
        public bool SensorDerecho { get; set; }

        public RegistroEstadoRobot(DateTime fechaHora, bool sensorIzquierdo, bool sensorDerecho)
        {
            FechaHora = fechaHora;
            SensorIzquierdo = sensorIzquierdo;
            SensorDerecho = sensorDerecho;
        }
    }
}
